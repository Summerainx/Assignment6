/*
-- Query: SELECT * FROM petstore.2014302580075_pet
LIMIT 0, 1000

-- Date: 2015-12-04 21:56
*/
INSERT INTO `2014302580075_pet` (`ID`,`Name`,`Eat`,`Drink`,`Live`,`Hobby`,`Price`) VALUES (1,'兔子','青菜，胡萝卜','水','草地，地洞','吃',288.00);
INSERT INTO `2014302580075_pet` (`ID`,`Name`,`Eat`,`Drink`,`Live`,`Hobby`,`Price`) VALUES (2,'金鱼','水草','水','水里','觅食，游来游去',60.00);
INSERT INTO `2014302580075_pet` (`ID`,`Name`,`Eat`,`Drink`,`Live`,`Hobby`,`Price`) VALUES (3,'哈士奇','肉，骨头','水','陆地','玩',300.00);
INSERT INTO `2014302580075_pet` (`ID`,`Name`,`Eat`,`Drink`,`Live`,`Hobby`,`Price`) VALUES (4,'小乌龟','fish,shrimp','水','水里，陆地','觅食，晒太阳',200.00);
INSERT INTO `2014302580075_pet` (`ID`,`Name`,`Eat`,`Drink`,`Live`,`Hobby`,`Price`) VALUES (5,'宠物猫','肉，火腿肠','水，牛奶','陆地','玩，晒太阳',235.00);
INSERT INTO `2014302580075_pet` (`ID`,`Name`,`Eat`,`Drink`,`Live`,`Hobby`,`Price`) VALUES (6,'松鼠','坚果','水','树上','跳来跳去，觅食',800.00);
INSERT INTO `2014302580075_pet` (`ID`,`Name`,`Eat`,`Drink`,`Live`,`Hobby`,`Price`) VALUES (7,'鹦鹉','坚果，种子','水','树上','飞来飞去，觅食',600.00);
INSERT INTO `2014302580075_pet` (`ID`,`Name`,`Eat`,`Drink`,`Live`,`Hobby`,`Price`) VALUES (8,'小鸭子','虫子，蚯蚓','水','陆地','游泳，觅食',150.00);
INSERT INTO `2014302580075_pet` (`ID`,`Name`,`Eat`,`Drink`,`Live`,`Hobby`,`Price`) VALUES (9,'小白鼠','馒头，火腿肠','水','地洞，墙洞','觅食，蹿来蹿去',60.00);
INSERT INTO `2014302580075_pet` (`ID`,`Name`,`Eat`,`Drink`,`Live`,`Hobby`,`Price`) VALUES (10,'宠物蛇','老鼠，肉','水','地洞，树上','觅食',500.00);
