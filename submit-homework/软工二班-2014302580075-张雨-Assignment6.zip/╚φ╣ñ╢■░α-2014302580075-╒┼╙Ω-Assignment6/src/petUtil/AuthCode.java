package petUtil;

import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

public class AuthCode {
	
	
	
	public static String sendAuthCode(String recipient) throws Exception {
		
		/*
		 * ���ӷ�����
		 */
		
		Properties props=new Properties();
		props.setProperty("mail.smtp.auth", "true");
		props.setProperty("mail.transport.protocol", "smtp");
		props.setProperty("mail.host", "smtp.sina.com");
		
		Session session=Session.getInstance(props, new Authenticator() {
			
			protected PasswordAuthentication getPasswordAuthentication()
			{
				return new PasswordAuthentication("summerainx@sina.com","cqmyg123456");
			}
		});
		/*
		 * ���÷��͵���Ϣ
		 */
		MimeMessage message=new MimeMessage(session);
		message.setFrom(new InternetAddress("summerainx@sina.com"));
		message.setRecipient(RecipientType.TO,new InternetAddress(recipient));
		message.setSubject("��֤��");
		String randomNumber="";
		Random random=new Random();
		int[] ints=new int[6];
		for (int i = 0; i < ints.length; i++) {
			randomNumber=randomNumber+Math.abs(random.nextInt()%10);
		}

		message.setContent("AuthCode:"+randomNumber, "text/plain");
		Transport.send(message);
		return randomNumber;
	}

}
