package petUtil;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbUtil {
	
	private String MySqlUrl="jdbc:mysql://localhost:3306/my_schema";
	private String userName="root";
	private String password="123456";
	private String jdbcName="com.mysql.jdbc.Driver";
	
	public Connection getCon() throws Exception {
		Class.forName(jdbcName);
		Connection con=DriverManager.getConnection(MySqlUrl, userName, password);
		return con;
	}
	public void closeCon(Connection connection) throws Exception {
		if (connection!=null) {
			connection.close();
		}
		
	}
}
