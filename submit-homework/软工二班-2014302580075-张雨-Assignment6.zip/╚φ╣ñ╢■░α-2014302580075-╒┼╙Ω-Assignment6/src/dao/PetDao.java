package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import petUtil.DbUtil;
import petstore.Pet;

public class PetDao {
	
	public static Pet queryPet(String name) throws Exception {
		DbUtil dbUtil=new DbUtil();
		Connection con=dbUtil.getCon();
		Pet resultPet=null;
		String sql="select * from 2014302580075_pet where Name=?";
		PreparedStatement preparedStatement=con.prepareStatement(sql);
		preparedStatement.setString(1, name);
		ResultSet resultSet=preparedStatement.executeQuery();
		while (resultSet.next()) {
			resultPet=new Pet();
			resultPet.setDrink(resultSet.getString("Drink"));
			resultPet.setEat(resultSet.getString("Eat"));
			resultPet.setHobby(resultSet.getString("Hobby"));
			resultPet.setLive(resultSet.getString("Live"));
			resultPet.setName(resultSet.getString("Name"));
			resultPet.setPrice(resultSet.getDouble("Price"));
			resultPet.setId(resultSet.getInt("ID"));
			
		}
		
		return resultPet;
	}
	public static double queryPetPrice(String petName) throws Exception {
		double price=0.00;
		DbUtil dbUtil=new DbUtil();
		Connection con=dbUtil.getCon();
		String sql="select Price from 2014302580075_pet where Name=?";
		PreparedStatement preparedStatement=con.prepareStatement(sql);
		preparedStatement.setString(1, petName);
		ResultSet resultSet=preparedStatement.executeQuery();
		while(resultSet.next()){
			price=resultSet.getDouble("Price");
		}
		
		return price;
	}
}
