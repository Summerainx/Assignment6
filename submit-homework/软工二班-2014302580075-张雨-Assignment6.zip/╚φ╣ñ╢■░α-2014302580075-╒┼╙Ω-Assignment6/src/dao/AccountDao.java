package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import petstore.Account;

public class AccountDao {
	
	public boolean updateAccount(Connection con,Account user) throws Exception {
		String sql="update 2014302580075_user set ID=?,Password=?,Blance=? where Account=?";
		PreparedStatement pstp=con.prepareStatement(sql);
		pstp.setInt(1, user.getID());
		pstp.setString(2, user.getPassword());
		pstp.setDouble(3, user.getBlance());
		pstp.setString(4, user.getAccount());
		int result=pstp.executeUpdate();
		if (result==1) {
			return true;
		}else {
			return false;
		}
		
	}
	
	public boolean updateBlance(Connection con,String account,double deposit) throws Exception {
		String sql="update 2014302580075_user set Blance=? where Account=?";
		PreparedStatement preparedStatement=con.prepareStatement(sql);
		double blance=this.queryBlance(con, account);
		preparedStatement.setDouble(1, deposit+blance);
		preparedStatement.setString(2, account);
		int result=preparedStatement.executeUpdate();
		if (result==1) {
			return true;
		}else {
			return false;
		}
		
	}
	
	public double queryBlance(Connection con,String account) throws Exception {
		String sql="select Blance from 2014302580075_user where Account=?";
		PreparedStatement preparedStatement=con.prepareStatement(sql);
		preparedStatement.setString(1, account);
		ResultSet resultSet=preparedStatement.executeQuery();
		while (resultSet.next()) {
			return resultSet.getDouble("Blance");
		}
		
		return -1;
	}
	
	public boolean deleteAccount(Connection con,String account) throws Exception {
		String sql="delete from 2014302580075_user where Account=?";
		
		PreparedStatement preparedStatement=con.prepareStatement(sql);
		preparedStatement.setString(1, account);
		int result=preparedStatement.executeUpdate();
		if (result==1) {
			return true;
		}else {
			return false;
		}
		
	}
	
	public  int insertAccount(Connection con,Account user) throws Exception {
		
		String sql="insert into 2014302580075_user(Account,Password,Blance)values(?,?,?)";
		PreparedStatement preparedStatement=con.prepareStatement(sql);
		preparedStatement.setString(1, user.getAccount());
		preparedStatement.setString(2, user.getPassword());
		preparedStatement.setDouble(3, user.getBlance());
		int result=preparedStatement.executeUpdate();
		return result;
	}
	public  Account queryAccount(Connection con,Account user) throws Exception {
		Account currentAccount=null;

		String sql="select * from 2014302580075_user where Account=? and Password=?";
		PreparedStatement preparedStatement=con.prepareStatement(sql);
		preparedStatement.setString(1, user.getAccount());
		preparedStatement.setString(2, user.getPassword());
		ResultSet resultSet=preparedStatement.executeQuery();
		while (resultSet.next()) {
			currentAccount=new Account();
			currentAccount.setAccount(resultSet.getString("Account"));
			currentAccount.setPassword(resultSet.getString("Password"));
			currentAccount.setID(resultSet.getInt("ID"));
			currentAccount.setBlance(resultSet.getDouble("Blance"));
		}
		resultSet.close();
		preparedStatement.close();
		return currentAccount;
	}
}
