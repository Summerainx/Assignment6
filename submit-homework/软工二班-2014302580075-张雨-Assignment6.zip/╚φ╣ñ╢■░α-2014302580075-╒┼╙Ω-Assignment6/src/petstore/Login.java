package petstore;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.AccountDao;
import petUtil.DbUtil;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 403);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel label = new JLabel("\u6B22\u8FCE\u767B\u9646");
		label.setIcon(new ImageIcon(Login.class.getResource("/images/Welcome_128px_1071652_easyicon.net.png")));
		label.setFont(new Font("����", Font.PLAIN, 28));
		
		JLabel lblAccount = new JLabel("\u8D26\u6237");
		lblAccount.setFont(new Font("����", Font.PLAIN, 14));
		lblAccount.setIcon(new ImageIcon(Login.class.getResource("/images/account_box_24px_1181627_easyicon.net.png")));
		
		JLabel lblPassword = new JLabel("\u5BC6\u7801");
		lblPassword.setFont(new Font("����", Font.PLAIN, 14));
		lblPassword.setIcon(new ImageIcon(Login.class.getResource("/images/password_24px_1169935_easyicon.net.png")));
		
		textField = new JTextField();
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		
		JButton btnLogin = new JButton("\u767B\u9646");
		btnLogin.setFont(new Font("����", Font.PLAIN, 14));
		btnLogin.setIcon(new ImageIcon(Login.class.getResource("/images/login_24px_1170189_easyicon.net.png")));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				auth(e);
			}
		});
		
		JButton btnReset = new JButton("\u91CD\u7F6E");
		btnReset.setFont(new Font("����", Font.PLAIN, 14));
		btnReset.setIcon(new ImageIcon(Login.class.getResource("/images/reset_24px_1083554_easyicon.net.png")));
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				resetValues(arg0);
			}
			
		});
		
		JButton btnSignup = new JButton("\u6CE8\u518C");
		btnSignup.setFont(new Font("����", Font.PLAIN, 14));
		btnSignup.setIcon(new ImageIcon(Login.class.getResource("/images/signup_24px_1098360_easyicon.net.png")));
		btnSignup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				SignUpFrm signUpFrm=new SignUpFrm();
				signUpFrm.setVisible(true);
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(63)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(label, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addContainerGap())
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblAccount)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(textField, GroupLayout.DEFAULT_SIZE, 223, Short.MAX_VALUE))
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
									.addGroup(gl_contentPane.createSequentialGroup()
										.addComponent(lblPassword)
										.addPreferredGap(ComponentPlacement.RELATED)
										.addComponent(passwordField))
									.addGroup(gl_contentPane.createSequentialGroup()
										.addComponent(btnLogin)
										.addPreferredGap(ComponentPlacement.RELATED)
										.addComponent(btnReset)
										.addPreferredGap(ComponentPlacement.RELATED)
										.addComponent(btnSignup, GroupLayout.PREFERRED_SIZE, 93, GroupLayout.PREFERRED_SIZE))))
							.addContainerGap(78, Short.MAX_VALUE))))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(label)
					.addGap(28)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAccount)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPassword)
						.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(26)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnLogin)
						.addComponent(btnReset)
						.addComponent(btnSignup))
					.addContainerGap(71, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
	/**
	 * ��½��֤
	 * @param e
	 */
	private void auth(ActionEvent event) {
		String userAccount=textField.getText();
		String userPassword=new String(passwordField.getPassword());
		
		if ("".equals(userAccount.trim())||userAccount==null) {//
			JOptionPane.showMessageDialog(null, "�˻�����Ϊ�գ�");
			return;
		}
		else if ("".equals(userPassword.trim())||userPassword==null) {
			JOptionPane.showMessageDialog(null, "���벻��Ϊ�գ�");
			return;
		}else {
			Account user=new Account(userAccount, userPassword);
			DbUtil dbUtil=new DbUtil();
			AccountDao accountDao=new AccountDao();
			try {
				Connection connection=dbUtil.getCon();
				Account currAccount=accountDao.queryAccount(connection, user);
				if (currAccount!=null) {
					dispose();
					StoreGUI storeGUI=new StoreGUI();
					storeGUI.setVisible(true);
					storeGUI.currentUser=currAccount;
					storeGUI.lblCurrentaccount.setText(currAccount.getAccount());
					storeGUI.textFieldBlance.setText(Double.toString(currAccount.getBlance())+"$");
					dbUtil.closeCon(connection);
				} else {
					JOptionPane.showMessageDialog(null, "�û����������������˻������ڣ�");
				}
				
			} catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
		}
		
		
	}

	private void resetValues(ActionEvent arg0) {
		
		textField.setText("");
		passwordField.setText("");
	}
}
