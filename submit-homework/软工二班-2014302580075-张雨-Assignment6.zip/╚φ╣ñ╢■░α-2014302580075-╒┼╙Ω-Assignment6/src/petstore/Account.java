package petstore;

import java.util.ArrayList;

public class Account {
	
	//�û���Ϣ
	private int ID;
	private String Account;
	private String Password;
	private double Blance;
	private ArrayList<Pet> car=new ArrayList<>();
	
	public Account() {
		// TODO �Զ����ɵĹ��캯�����
	}
	
	public Account(String account, String password) {
		super();
		Account = account;
		Password = password;
		Blance=0.00;
	}
	public void rigesit(String Name,String Password) {
		
	}
	public boolean auth(String Name,String Password) {
		
		return true;
	}
	public void addToCar(Pet pet) {
		
	}
	
	public void clearCar() {
		
	}
	public ArrayList<Pet> getCar() {
		return car;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getAccount() {
		return Account;
	}
	public void setAccount(String account) {
		Account = account;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public double getBlance() {
		return Blance;
	}
	public void setBlance(double blance) {
		Blance = blance;
	}
	public void setCar(ArrayList<Pet> car) {
		this.car = car;
	}
	
	
}
