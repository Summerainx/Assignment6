package petstore;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.AccountDao;
import dao.PetDao;
import petUtil.DbUtil;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JComboBox;
import java.awt.Toolkit;

public class StoreGUI extends JFrame {

	private JPanel contentPane;
	public JTextField textFieldBlance;
	public JLabel lblCurrentaccount;
	private JTextField textFieldMoney;
	public Account currentUser=null;
	private JTextField textFieldSelectedPet;
	private JTextField textFieldPetNumber;
	private JComboBox<String> comboBox;
	private JTextField textFieldTotal;
	

	/**
	 * Create the frame.
	 */
	public StoreGUI() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(StoreGUI.class.getResource("/images/store_24px_1149809_easyicon.net.png")));
		setTitle("\u5BA0\u7269\u5546\u5E97");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 576, 392);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(117, 0, 302, 211);
		contentPane.add(scrollPane);
		
		JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		
		JButton btnRabbit = new JButton("\u5154\u5B50");
		btnRabbit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Pet currentPet=PetDao.queryPet(btnRabbit.getText());
					textArea.setText("����ID��"+currentPet.getId()+"\n"+"�������ƣ�"+currentPet.getName()+"\n"+"ʳ�"+currentPet.getEat()+
							"\n"+"�ȣ�"+currentPet.getDrink()+"\n"+"�������"+currentPet.getLive()+"\n"+"���ã�"+currentPet.getHobby()+"\n"+"�۸�"+currentPet.getPrice()+"$");
					textFieldSelectedPet.setText(currentPet.getName());
					
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
				
				
			}
		});
		btnRabbit.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/Rabbit.png")));
		btnRabbit.setBounds(0, 19, 107, 23);
		contentPane.add(btnRabbit);
		
		JButton btnGoidfish = new JButton("\u91D1\u9C7C");
		btnGoidfish.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Pet currentPet=PetDao.queryPet(btnGoidfish.getText());
					textArea.setText("����ID��"+currentPet.getId()+"\n"+"�������ƣ�"+currentPet.getName()+"\n"+"ʳ�"+currentPet.getEat()+
							"\n"+"�ȣ�"+currentPet.getDrink()+"\n"+"�������"+currentPet.getLive()+"\n"+"���ã�"+currentPet.getHobby()+"\n"+"�۸�"+currentPet.getPrice()+"$");
					textFieldSelectedPet.setText(currentPet.getName());
					
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
			}
		});
		btnGoidfish.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/fish_24px_511646_easyicon.net.png")));
		btnGoidfish.setBounds(0, 52, 107, 23);
		contentPane.add(btnGoidfish);
		
		JButton btnHuskie = new JButton("\u54C8\u58EB\u5947");
		btnHuskie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Pet currentPet=PetDao.queryPet(btnHuskie.getText());
					textArea.setText("����ID��"+currentPet.getId()+"\n"+"�������ƣ�"+currentPet.getName()+"\n"+"ʳ�"+currentPet.getEat()+
							"\n"+"�ȣ�"+currentPet.getDrink()+"\n"+"�������"+currentPet.getLive()+"\n"+"���ã�"+currentPet.getHobby()+"\n"+"�۸�"+currentPet.getPrice()+"$");
					textFieldSelectedPet.setText(currentPet.getName());
					
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
			}
		});
		btnHuskie.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/haski_dog_24px_1165300_easyicon.net.png")));
		btnHuskie.setBounds(0, 85, 107, 23);
		contentPane.add(btnHuskie);
		
		JButton btnTortoise = new JButton("\u5C0F\u4E4C\u9F9F");
		btnTortoise.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Pet currentPet=PetDao.queryPet(btnTortoise.getText());
					textArea.setText("����ID��"+currentPet.getId()+"\n"+"�������ƣ�"+currentPet.getName()+"\n"+"ʳ�"+currentPet.getEat()+
							"\n"+"�ȣ�"+currentPet.getDrink()+"\n"+"�������"+currentPet.getLive()+"\n"+"���ã�"+currentPet.getHobby()+"\n"+"�۸�"+currentPet.getPrice()+"$");
					textFieldSelectedPet.setText(currentPet.getName());
					
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
			}
		});
		btnTortoise.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/dribbble_mascot_Tortoise_24px_546090_easyicon.net.png")));
		btnTortoise.setBounds(0, 118, 107, 23);
		contentPane.add(btnTortoise);
		
		JButton btnCat = new JButton("\u5BA0\u7269\u732B");
		btnCat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Pet currentPet=PetDao.queryPet(btnCat.getText());
					textArea.setText("����ID��"+currentPet.getId()+"\n"+"�������ƣ�"+currentPet.getName()+"\n"+"ʳ�"+currentPet.getEat()+
							"\n"+"�ȣ�"+currentPet.getDrink()+"\n"+"�������"+currentPet.getLive()+"\n"+"���ã�"+currentPet.getHobby()+"\n"+"�۸�"+currentPet.getPrice()+"$");
					textFieldSelectedPet.setText(currentPet.getName());
					
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
			}
		});
		btnCat.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/cat_lovely_24px_526541_easyicon.net.png")));
		btnCat.setBounds(0, 151, 107, 23);
		contentPane.add(btnCat);
		
		JButton btnSnake = new JButton("\u5BA0\u7269\u86C7");
		btnSnake.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Pet currentPet=PetDao.queryPet(btnSnake.getText());
					textArea.setText("����ID��"+currentPet.getId()+"\n"+"�������ƣ�"+currentPet.getName()+"\n"+"ʳ�"+currentPet.getEat()+
							"\n"+"�ȣ�"+currentPet.getDrink()+"\n"+"�������"+currentPet.getLive()+"\n"+"���ã�"+currentPet.getHobby()+"\n"+"�۸�"+currentPet.getPrice()+"$");
					textFieldSelectedPet.setText(currentPet.getName());
					
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
			}
		});
		btnSnake.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/Snake_24px_544102_easyicon.net.png")));
		btnSnake.setBounds(429, 151, 107, 23);
		contentPane.add(btnSnake);
		
		JButton btnSquirrel = new JButton("\u677E\u9F20");
		btnSquirrel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Pet currentPet=PetDao.queryPet(btnSquirrel.getText());
					textArea.setText("����ID��"+currentPet.getId()+"\n"+"�������ƣ�"+currentPet.getName()+"\n"+"ʳ�"+currentPet.getEat()+
							"\n"+"�ȣ�"+currentPet.getDrink()+"\n"+"�������"+currentPet.getLive()+"\n"+"���ã�"+currentPet.getHobby()+"\n"+"�۸�"+currentPet.getPrice()+"$");
					textFieldSelectedPet.setText(currentPet.getName());
					
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
			}
		});
		btnSquirrel.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/squirrel_19.68253968254px_1167509_easyicon.net.png")));
		btnSquirrel.setBounds(429, 19, 107, 23);
		contentPane.add(btnSquirrel);
		
		JButton btnParrot = new JButton("\u9E66\u9E49");
		btnParrot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Pet currentPet=PetDao.queryPet(btnParrot.getText());
					textArea.setText("����ID��"+currentPet.getId()+"\n"+"�������ƣ�"+currentPet.getName()+"\n"+"ʳ�"+currentPet.getEat()+
							"\n"+"�ȣ�"+currentPet.getDrink()+"\n"+"�������"+currentPet.getLive()+"\n"+"���ã�"+currentPet.getHobby()+"\n"+"�۸�"+currentPet.getPrice()+"$");
					textFieldSelectedPet.setText(currentPet.getName());
					
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
			}
		});
		btnParrot.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/Parrot_24px_501925_easyicon.net.png")));
		btnParrot.setBounds(429, 52, 107, 23);
		contentPane.add(btnParrot);
		
		JButton btnDuck = new JButton("\u5C0F\u9E2D\u5B50");
		btnDuck.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Pet currentPet=PetDao.queryPet(btnDuck.getText());
					textArea.setText("����ID��"+currentPet.getId()+"\n"+"�������ƣ�"+currentPet.getName()+"\n"+"ʳ�"+currentPet.getEat()+
							"\n"+"�ȣ�"+currentPet.getDrink()+"\n"+"�������"+currentPet.getLive()+"\n"+"���ã�"+currentPet.getHobby()+"\n"+"�۸�"+currentPet.getPrice()+"$");
					textFieldSelectedPet.setText(currentPet.getName());
					
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
			}
		});
		btnDuck.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/Ugly_Duck_24px_501928_easyicon.net.png")));
		btnDuck.setBounds(429, 85, 107, 23);
		contentPane.add(btnDuck);
		
		JButton btnRat = new JButton("\u5C0F\u767D\u9F20");
		btnRat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Pet currentPet=PetDao.queryPet(btnRat.getText());
					textArea.setText("����ID��"+currentPet.getId()+"\n"+"�������ƣ�"+currentPet.getName()+"\n"+"ʳ�"+currentPet.getEat()+
							"\n"+"�ȣ�"+currentPet.getDrink()+"\n"+"�������"+currentPet.getLive()+"\n"+"���ã�"+currentPet.getHobby()+"\n"+"�۸�"+currentPet.getPrice()+"$");
					textFieldSelectedPet.setText(currentPet.getName());
					
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
			}
		});
		btnRat.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/Rat_24px_544104_easyicon.net.png")));
		btnRat.setBounds(429, 118, 107, 23);
		contentPane.add(btnRat);
		
		JButton btnBlance = new JButton("\u4F59\u989D");
		btnBlance.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/money_bag_25.012464046021px_1192959_easyicon.net.png")));
		btnBlance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showBlance(e);
			}
		});
		btnBlance.setBounds(10, 220, 97, 23);
		contentPane.add(btnBlance);
		
		textFieldBlance = new JTextField();
		textFieldBlance.setBounds(116, 221, 91, 21);
		contentPane.add(textFieldBlance);
		textFieldBlance.setColumns(10);
		
		JButton btnBuy = new JButton("\u8D2D\u4E70");
		btnBuy.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/buy_24px_1168842_easyicon.net.png")));
		btnBuy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					buyFromCar(e);
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
			}
		});
		btnBuy.setBounds(384, 331, 162, 23);
		contentPane.add(btnBuy);
		
		JButton btnAdd = new JButton("\u6DFB\u52A0\u81F3\u8D2D\u7269\u8F66");
		btnAdd.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/Card_add_25.614035087719px_1191024_easyicon.net.png")));
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					addToCar(e);
				} catch (NumberFormatException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
			}
		});
		btnAdd.setBounds(236, 266, 162, 23);
		contentPane.add(btnAdd);
		
		JButton btnLogout = new JButton("\u6CE8\u9500");
		btnLogout.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/LogOff_22.336633663366px_1183483_easyicon.net.png")));
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				logOutAction(e);
			}
		});
		btnLogout.setBounds(10, 299, 97, 23);
		contentPane.add(btnLogout);
		
		JButton btnDeleteaccount = new JButton("\u5220\u9664\u8D26\u6237");
		btnDeleteaccount.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/Delete_17.975510204082px_1190332_easyicon.net.png")));
		btnDeleteaccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					deleteAccountPreformed(e);
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
			}
		});
		btnDeleteaccount.setBounds(116, 299, 110, 23);
		contentPane.add(btnDeleteaccount);
		
		JLabel lblCurrentuser = new JLabel("\u5F53\u524D\u7528\u6237:");
		lblCurrentuser.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/account_box_24px_1181627_easyicon.net.png")));
		lblCurrentuser.setBounds(10, 332, 97, 21);
		contentPane.add(lblCurrentuser);
		
		lblCurrentaccount = new JLabel("NULL");
		lblCurrentaccount.setBounds(98, 333, 276, 18);
		contentPane.add(lblCurrentaccount);
		
		JButton btnDeposit = new JButton("\u5B58\u5165");
		btnDeposit.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/deposit_24px_572814_easyicon.net.png")));
		btnDeposit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					if (changeBlance(e)) {
						JOptionPane.showMessageDialog(null, "����ɹ���");
					} else {
						JOptionPane.showMessageDialog(null, "����ʧ�ܣ�");
					}
					showBlance();
					textFieldMoney.setText("");
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
			}
		});
		btnDeposit.setBounds(10, 254, 97, 23);
		contentPane.add(btnDeposit);
		
		textFieldMoney = new JTextField();
		textFieldMoney.setBounds(117, 252, 91, 21);
		contentPane.add(textFieldMoney);
		textFieldMoney.setColumns(10);
		
		JLabel label = new JLabel("$");
		label.setFont(new Font("����", Font.PLAIN, 16));
		label.setBounds(209, 252, 17, 15);
		contentPane.add(label);
		
		JLabel lblSelectedpet = new JLabel("\u5F53\u524D\u9009\u62E9\u7684\u5BA0\u7269");
		lblSelectedpet.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/pet_26.445283018868px_1194997_easyicon.net.png")));
		lblSelectedpet.setBounds(236, 224, 139, 23);
		contentPane.add(lblSelectedpet);
		
		textFieldSelectedPet = new JTextField();
		textFieldSelectedPet.setBounds(361, 222, 91, 21);
		contentPane.add(textFieldSelectedPet);
		textFieldSelectedPet.setColumns(10);
		
		JLabel lblMultisign = new JLabel("X");
		lblMultisign.setFont(new Font("����", Font.PLAIN, 17));
		lblMultisign.setBounds(462, 223, 17, 15);
		contentPane.add(lblMultisign);
		
		textFieldPetNumber = new JTextField();
		textFieldPetNumber.setText("1");
		textFieldPetNumber.setBounds(480, 221, 66, 22);
		contentPane.add(textFieldPetNumber);
		textFieldPetNumber.setColumns(10);
		
		comboBox = new JComboBox();
		comboBox.setBounds(423, 267, 123, 21);
		contentPane.add(comboBox);
		
		JButton btnDelete = new JButton("\u4ECE\u8D2D\u7269\u8F66\u4E2D\u5220\u9664");
		btnDelete.setIcon(new ImageIcon(StoreGUI.class.getResource("/images/trolley_remove_27.745664739884px_1189863_easyicon.net.png")));
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deleteFromCar(e);
			}
		});
		btnDelete.setBounds(236, 299, 162, 23);
		contentPane.add(btnDelete);
		
		JLabel lblTotal = new JLabel("\u5408\u8BA1");
		lblTotal.setBounds(423, 303, 30, 15);
		contentPane.add(lblTotal);
		
		textFieldTotal = new JTextField();
		textFieldTotal.setText("0");
		textFieldTotal.setBounds(453, 300, 66, 21);
		contentPane.add(textFieldTotal);
		textFieldTotal.setColumns(10);
		
		JLabel label_1 = new JLabel("$");
		label_1.setFont(new Font("����", Font.PLAIN, 16));
		label_1.setBounds(519, 302, 17, 15);
		contentPane.add(label_1);
	}
	/**
	 * ���ﳵ����
	 * @param e
	 * @throws Exception 
	 */
	private void buyFromCar(ActionEvent event) throws Exception {
		double sumMoney=0.00;
		int count=comboBox.getItemCount();
		for (int i = 0; i <count; i++) {
			String[] itemString=comboBox.getItemAt(i).split("X");
			String petName=itemString[0];
			String num=itemString[1];
			sumMoney=sumMoney+PetDao.queryPetPrice(petName)*Integer.parseInt(num);
		}
		DbUtil dbUtil=new DbUtil();
		AccountDao aDao=new AccountDao();
		Connection con=dbUtil.getCon();
		
		double blance=aDao.queryBlance(con, currentUser.getAccount());
		blance=blance-sumMoney;
		if (blance<=0) {
			JOptionPane.showMessageDialog(null, "���㣡���ֵ��");
		}else {
			JOptionPane.showMessageDialog(null, "����ɹ���");
			currentUser.setBlance(blance);
			aDao.updateAccount(con, currentUser);
			showBlance();
			comboBox.removeAllItems();
			textFieldTotal.setText("0");
		}
		
		
	}

	/**
	 * �ӹ��ﳵ��ɾ��
	 * @param e
	 */
	private void deleteFromCar(ActionEvent e) {
		String selectedObj=(String) comboBox.getSelectedItem();
		comboBox.removeItem(selectedObj);
		
	}

	/**
	 * ���������ﳵ
	 * @param e
	 * @throws Exception 
	 * @throws NumberFormatException 
	 */
	private void addToCar(ActionEvent e) throws NumberFormatException, Exception {
		String currentSelect=textFieldSelectedPet.getText();
		 //���Ӷ��������ֵ��ж�
		String number=textFieldPetNumber.getText();
		comboBox.addItem(currentSelect+"X"+number);
		textFieldPetNumber.setText("1");
		double sumMoney=0.00;
		int count=comboBox.getItemCount();
		for (int i = 0; i <count; i++) {
			String[] itemString=comboBox.getItemAt(i).split("X");
			String petName=itemString[0];
			String num=itemString[1];
			sumMoney=sumMoney+PetDao.queryPetPrice(petName)*Integer.parseInt(num);
		}
		textFieldTotal.setText(Double.toString(sumMoney));
	}
	/**
	 * ע���˻�
	 * @param e
	 */
	private void logOutAction(ActionEvent e) {
		
		dispose();
		Login login=new Login();
		login.setVisible(true);
		currentUser=null;
		
	}
	/**
	 * ��Ǯ
	 * @param e
	 * @return
	 * @throws Exception
	 */
	protected boolean changeBlance(ActionEvent e) throws Exception {
		double deposit=Double.parseDouble(textFieldMoney.getText());
		DbUtil dbUtil=new DbUtil();
		AccountDao accountDao=new AccountDao();
		Connection con=dbUtil.getCon();
		double blance=accountDao.queryBlance(con, currentUser.getAccount());
		currentUser.setBlance(blance+deposit);
		return accountDao.updateBlance(con, currentUser.getAccount(), deposit);
	}
	/**
	 * ��ʾ���
	 */
	private void showBlance() {
			
			textFieldBlance.setText(Double.toString(currentUser.getBlance())+"$");
			
		}
	/**
	 * ��ʾ���
	 * @param event
	 */
	private void showBlance(ActionEvent event) {
		
		textFieldBlance.setText(Double.toString(currentUser.getBlance())+"$");
		
	}
	
	/**
	 * ɾ���˻�
	 * @param event
	 * @throws Exception
	 */
	private void deleteAccountPreformed(ActionEvent event) throws Exception {
		DbUtil dbUtil=new DbUtil();
		AccountDao accountDao=new AccountDao();
		Connection connection=dbUtil.getCon();
		boolean result=accountDao.deleteAccount(connection,lblCurrentaccount.getText());
		if (result) {
			JOptionPane.showMessageDialog(null, "�ɹ�ɾ���˻���");
			dispose();
			Login login=new Login();
			login.setVisible(true);
			lblCurrentaccount.setText("NULL");
		}else {
			JOptionPane.showMessageDialog(null, "�˻�ɾ��ʧ�ܣ�");
		}
	}
}
