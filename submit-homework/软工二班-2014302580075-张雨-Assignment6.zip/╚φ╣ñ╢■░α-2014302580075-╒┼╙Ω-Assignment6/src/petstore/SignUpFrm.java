package petstore;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.AccountDao;
import petUtil.AuthCode;
import petUtil.DbUtil;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.ImageIcon;

public class SignUpFrm extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldEmail;
	private JPasswordField passwordField;
	private JTextField textFieldAuthCode;
	private JLabel lblAuthCodestate;
	private String authcode="";


	/**
	 * Create the frame.
	 */
	public SignUpFrm() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 408);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblWelcome = new JLabel("\u6B22\u8FCE\u6CE8\u518C");
		lblWelcome.setIcon(new ImageIcon(SignUpFrm.class.getResource("/images/Welcome_128px_1071652_easyicon.net.png")));
		lblWelcome.setFont(new Font("����", Font.PLAIN, 28));
		lblWelcome.setBounds(51, 10, 311, 141);
		contentPane.add(lblWelcome);
		
		JLabel lblName = new JLabel("\u90AE\u7BB1");
		lblName.setIcon(new ImageIcon(SignUpFrm.class.getResource("/images/email_33.752508361204px_1197077_easyicon.net.png")));
		lblName.setBounds(49, 165, 65, 30);
		contentPane.add(lblName);
		
		JLabel lblPassword = new JLabel("\u5BC6\u7801");
		lblPassword.setIcon(new ImageIcon(SignUpFrm.class.getResource("/images/password_24px_1169935_easyicon.net.png")));
		lblPassword.setBounds(49, 205, 65, 30);
		contentPane.add(lblPassword);
		
		textFieldEmail = new JTextField();
		textFieldEmail.setBounds(119, 167, 190, 29);
		contentPane.add(textFieldEmail);
		textFieldEmail.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(119, 207, 190, 29);
		contentPane.add(passwordField);
		
		JButton btnSubmit = new JButton("\u63D0\u4EA4");
		btnSubmit.setIcon(new ImageIcon(SignUpFrm.class.getResource("/images/login_24px_1170189_easyicon.net.png")));
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					
					DbUtil dbUtil=new DbUtil();
					AccountDao accountDao=new AccountDao();
					Connection con=dbUtil.getCon();
					if (textFieldEmail.getText()==null||"".equals(textFieldEmail.getText().trim())) {
						JOptionPane.showMessageDialog(null, "�˻���Ϊ�գ�");
						return;
					} else if(new String(passwordField.getPassword())==null||"".equals(new String(passwordField.getPassword()).trim())){
						JOptionPane.showMessageDialog(null, "����Ϊ�գ�");
						return;
					}else {
							if (authcode.equals(textFieldAuthCode.getText().trim())) {//
							
								Account user=new Account(textFieldEmail.getText(),new String(passwordField.getPassword()));
								int result=accountDao.insertAccount(con, user);
								if (result==1) {
									JOptionPane.showMessageDialog(null, "ע��ɹ���");
									dispose();
									Login login=new Login();
									login.setVisible(true);
								} else {
									JOptionPane.showMessageDialog(null, "ע��ʧ�ܣ�");
			
								}
							
						}else {
							
							JOptionPane.showMessageDialog(null, "��֤�������������д��");
							
						}
						
					}
					
					
				} catch (Exception e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			
			}
		});
		btnSubmit.setBounds(51, 296, 100, 30);
		contentPane.add(btnSubmit);
		
		JButton btnReset = new JButton("\u91CD\u7F6E");
		btnReset.setIcon(new ImageIcon(SignUpFrm.class.getResource("/images/reset_24px_1083554_easyicon.net.png")));
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				resetValue(e);
			}
		});
		btnReset.setBounds(209, 296, 100, 30);
		contentPane.add(btnReset);
		
		JButton btnGetauthcode = new JButton("\u83B7\u53D6\u9A8C\u8BC1\u7801");
		btnGetauthcode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					sendAuthCode(e);
				} catch (Exception e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
			}
		});
		btnGetauthcode.setBounds(51, 243, 100, 30);
		contentPane.add(btnGetauthcode);
		
		textFieldAuthCode = new JTextField();
		textFieldAuthCode.setBounds(161, 246, 100, 26);
		contentPane.add(textFieldAuthCode);
		textFieldAuthCode.setColumns(10);
		
		lblAuthCodestate = new JLabel("\u9A8C\u8BC1\u7801\u672A\u53D1\u9001");
		lblAuthCodestate.setBounds(269, 246, 165, 23);
		contentPane.add(lblAuthCodestate);
	}

	/**
	 * ����ע����֤��
	 * @param e
	 * @throws Exception 
	 */
	private void sendAuthCode(ActionEvent e) throws Exception {
		if (textFieldEmail.getText()==null||"".equals(textFieldEmail.getText().trim())) {
			JOptionPane.showMessageDialog(null, "�˻���Ϊ�գ�");
			return;
		} else if(new String(passwordField.getPassword())==null||"".equals(new String(passwordField.getPassword()).trim())){
			JOptionPane.showMessageDialog(null, "����Ϊ�գ�");
			return;
		}else {
			String regexEmail="\\w@\\w{2,}.\\w{2,}+";//\\w{3,}@\\w+(\\.\\w{2,3}){1,3}
			String email=textFieldEmail.getText();
			Pattern pEmail=Pattern.compile(regexEmail);
			Matcher matcher=pEmail.matcher(email);
			if (matcher.find()) {
				authcode=AuthCode.sendAuthCode(email);
				lblAuthCodestate.setText("��֤���ѷ��ͣ�����գ�");
			}else {
				JOptionPane.showMessageDialog(null, "��������ȷ��ʽ�����䣡");
			}
		}
	
	}

	/**
	 * ����
	 * @param e
	 */
	private void resetValue(ActionEvent e) {
		textFieldEmail.setText("");
		passwordField.setText("");
	}
}
