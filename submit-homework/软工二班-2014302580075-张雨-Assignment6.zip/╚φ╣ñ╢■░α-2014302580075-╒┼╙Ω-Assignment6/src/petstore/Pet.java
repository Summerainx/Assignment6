package petstore;

public class Pet {
	
	/*
	 * ������Ϣ����
	 */
	private int Id;
	private String Name;
	private String Eat;
	private String Drink;
	private String Live;
	private String Hobby;
	private double Price;
	
	public String getLive() {
		return Live;
	}
	public void setLive(String live) {
		Live = live;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	
	public double getPrice() {
		return Price;
	}
	public void setPrice(double price) {
		Price = price;
	}
	public String getEat() {
		return Eat;
	}
	public void setEat(String eat) {
		this.Eat = eat;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getDrink() {
		return Drink;
	}
	public void setDrink(String drink) {
		Drink = drink;
	}
	public String getHobby() {
		return Hobby;
	}
	public void setHobby(String hobby) {
		Hobby = hobby;
	}
	

}
