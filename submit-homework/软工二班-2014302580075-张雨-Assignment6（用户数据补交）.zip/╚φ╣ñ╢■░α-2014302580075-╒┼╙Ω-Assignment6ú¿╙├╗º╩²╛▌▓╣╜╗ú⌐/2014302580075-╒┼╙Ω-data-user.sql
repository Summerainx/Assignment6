/*
-- Query: SELECT * FROM petstore.2014302580075_user
LIMIT 0, 1000

-- Date: 2015-12-04 21:58
*/
INSERT INTO `2014302580075_user` (`ID`,`Account`,`Password`,`Blance`) VALUES (1,'test ','1234',4130);
